package Tcp

import ResourceManagerCode.*

class Middleware(val server: String,
                 val requestIdStart: Int,
                 val resourceType: MutableMap<String, ReservableType> = mutableMapOf(),
                 private val customerRm: ResourceManager = TcpRequestSender(PortNumbers.customerRm, server, requestIdStart),
                 private val flightRm: ResourceManager = TcpRequestSender(PortNumbers.flightRm, server, requestIdStart),
                 private val hotelRm: ResourceManager = TcpRequestSender(PortNumbers.hotelRm, server, requestIdStart),
                 private val carRm: ResourceManager = TcpRequestSender(PortNumbers.carRm, server, requestIdStart)) : ResourceManager {



    fun getRm(type: ReservableType): ResourceManager {
        return when(type) {
            ReservableType.FLIGHT -> flightRm
            ReservableType.HOTEL -> hotelRm
            ReservableType.CAR -> carRm
        }
    }

    override fun createResource(type: ReservableType, resourceId: String, totalQuantity: Int, price: Int): Boolean {
        if (getRm(type).createResource(type, resourceId, totalQuantity, price)) {
            resourceType.put(resourceId, type)
            return true
        }
        return false
    }

    override fun updateResource(resourceId: String, newTotalQuantity: Int, newPrice: Int): Boolean {
        return getRm(resourceType[resourceId] ?: return false).updateResource(resourceId, newTotalQuantity, newPrice)
    }

    override fun reserveResource(resourceId: String, reservationQuantity: Int): Boolean {
        return getRm(resourceType[resourceId] ?: return false).reserveResource(resourceId, reservationQuantity)
    }

    override fun deleteResource(resourceId: String): Boolean {

        if (getRm(resourceType[resourceId] ?: return false).deleteResource(resourceId)) {
            resourceType.remove(resourceId)
            return true
        }
        println("could not delete")
        return false
    }

    override fun queryResource(resourceId: String): Resource? {
        return getRm(resourceType[resourceId] ?: return null).queryResource(resourceId)
    }

    override fun uniqueCustomerId(): Int {
        return customerRm.uniqueCustomerId()
    }

    override fun createCustomer(customerId: Int): Boolean {
        return customerRm.createCustomer(customerId)
    }

    override fun deleteCustomer(customerId: Int): Boolean {
        return customerRm.deleteCustomer(customerId)
    }

    override fun queryCustomer(customerId: Int): Customer? {
        return customerRm.queryCustomer(customerId)
    }

    override fun customerAddReservation(customerId: Int, reservationId: Int, reservableItem: ReservableItem): Boolean {

        val customer: Customer? = queryCustomer(customerId)
        if (customer != null) {
            if (reserveResource(reservableItem.id, 1)) {
                val resource = queryResource(reservableItem.id)?.item ?: return false
                if (customer.addReservation(Reservation(reservationId, reservableItem, 1, reservableItem.price))) {
                    return true
                } else {
                    // customer may have been deleted in the meantime
                    reserveResource(reservableItem.id, -1)
                }
            }
        }
        return false
    }

    override fun customerRemoveReservation(customerId: Int, reservationId: Int): Boolean {

        val customer: Customer = queryCustomer(customerId) ?: return false
        val reservation = customer.reservations.find { r -> r.reservationId == reservationId } ?: return false
        customer.removeReservation(reservationId)
        reserveResource(reservation.item.id, -1)
        return false
    }

    override fun itinerary(customerId: Int, reservationResources: MutableMap<Int, ReservableItem>): Boolean {

        data class Reserved(val rResourceId: String, val rReservationId: Int)

        val reserved: MutableMap<Int, Reserved> = mutableMapOf()

        for ((reservationId, reservableItem) in reservationResources){
            if ( customerAddReservation(customerId, reservationId, reservableItem) == true) {
                reserved.put(customerId, Reserved(reservableItem.id, reservationId))
            } else {
                // if any of the fail, undo the reservations so far
                reserved.forEach({(cId, reserved) ->
                    customerRemoveReservation(cId, reserved.rReservationId)
                    reserveResource(reserved.rResourceId, -1 )
                    return false
                })
            }

        }
        return true
    }

}