package ResourceManagerCode

enum class ReservableType {

    HOTEL,
    FLIGHT,
    CAR
}
