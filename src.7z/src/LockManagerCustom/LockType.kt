package LockManagerCustom

enum class LockType{
    READ, WRITE
}